$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path

# Find ALL .doc files in the same directory as this script, excluding MS Word temporary lock files starting with ~$
$docFiles = Get-ChildItem -Path $scriptPath -Filter "*.doc" | Where-Object { $_.Name -notmatch "^\~\$" }

if ($docFiles.Count -eq 0) {
    Write-Host "❌ ไม่พบไฟล์ .doc ใดๆ ในโฟลเดอร์นี้ ($scriptPath)" -ForegroundColor Red
    Write-Host "กรุณานำไฟล์ต้นแบบ '.doc' มาไว้ข้างๆ สคริปต์นี้แล้วรันใหม่อีกครั้ง" -ForegroundColor Yellow
    Read-Host "กด Enter เพื่อปิด"
    exit
}

$outputDir = Join-Path -Path $scriptPath -ChildPath "converted docx files"
if (-not (Test-Path -Path $outputDir)) {
    New-Item -ItemType Directory -Path $outputDir | Out-Null
}

Write-Host "📂 ค้นพบเอกสารที่ต้องแปลงทั้งหมด: $($docFiles.Count) ไฟล์" -ForegroundColor Cyan
Write-Host "🔄 กำลังเรียกเปิด Microsoft Word (COM API) เพื่อเตรียมพร้อม..." -ForegroundColor Yellow

try {
    # 1. Start COM application for Microsoft Word once
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0 # wdAlertsNone
    
    $successCount = 0

    foreach ($docFile in $docFiles) {
        $inputFile = $docFile.FullName
        $baseName = [System.IO.Path]::GetFileNameWithoutExtension($inputFile)
        $outputFile = Join-Path -Path $outputDir -ChildPath "$baseName.docx"
        $filename = $docFile.Name
        
        Write-Host "⏳ [กำลังประมวลผล] -> $filename ..." -ForegroundColor Gray

        try {
            # 2. Open Document
            $doc = $word.Documents.Open($inputFile)
            
            # 3. Save as .docx format (wdFormatXMLDocument = 16)
            $doc.SaveAs([ref]$outputFile, [ref]16)
            
            # Close document
            $doc.Close()
            [System.Runtime.Interopservices.Marshal]::ReleaseComObject($doc) | Out-Null
            
            Write-Host "   ✅ สำเร็จ -> เปลี่ยนนามสกุลเป็น .docx สมบูรณ์" -ForegroundColor Green
            $successCount++
        } catch {
             Write-Host "   ❌ ล้มเหลว -> รหัสข้อผิดพลาด: $_" -ForegroundColor Red
        }
    }
    
    # Quit Word
    $word.Quit()
    
    # Release COM memory
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($word) | Out-Null
    [System.GC]::Collect()
    [System.GC]::WaitForPendingFinalizers()

    # Clean up lock files (Allowing Word time to release them)
    Start-Sleep -Seconds 2
    Write-Host "`n🧹 กำลังทำความสะอาดไฟล์ชั่วคราว..." -ForegroundColor Cyan
    $lockFiles = Get-ChildItem -Path $scriptPath -Force | Where-Object { $_.Name -match "^\~\$.*\.do[cx]?$" }
    foreach ($lf in $lockFiles) {
        try {
            Remove-Item -Path $lf.FullName -Force -ErrorAction Stop
            Write-Host "   🗑️ ลบไฟล์ขยะ: $($lf.Name)" -ForegroundColor DarkGray
        } catch {
            Write-Host "   ⚠️ ไม่สามารถลบได้ (อาจถูกยึดครอง): $($lf.Name)" -ForegroundColor Yellow
        }
    }

    Write-Host "`n🎉 สิ้นสุดกระบวนการ! แปลงไฟล์สำเร็จจำนวน: $successCount / $($docFiles.Count) ไฟล์" -ForegroundColor Green
    Write-Host "📁 ตรวจสอบไฟล์ผลลัพธ์ได้ที่โฟลเดอร์: converted docx files" -ForegroundColor Cyan
    
} catch {
    Write-Host "❌ เกิดข้อผิดพลาดร้ายแรงกับเอนจิน Word: $_" -ForegroundColor Red
    if ($word) {
        $word.Quit()
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($word) | Out-Null
    }
}

Read-Host "`nกด Enter เพื่อปิดหน้าต่างนี้..."
