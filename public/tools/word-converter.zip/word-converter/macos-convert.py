import os
import glob
import subprocess
import time
import shutil

def convert_all_docs_to_docx():
    # 1. Define paths
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    cwd = os.getcwd()
    search_dir = cwd if cwd != BASE_DIR else BASE_DIR

    # Find ALL .doc files in directory (case-insensitive glob if possible, but standard glob is case-sensitive on some OS. Good enough for now)
    all_doc_files = glob.glob(os.path.join(search_dir, '*.doc'))
    
    # Exclude MS Word temporary lock files (e.g., ~$mplate.doc)
    doc_files = [f for f in all_doc_files if not os.path.basename(f).startswith('~$')]
    
    if not doc_files:
        print(f"❌ ไม่พบไฟล์ .doc ใดๆ ในโฟลเดอร์ {search_dir}")
        print("กรุณานำสคริปต์นี้ไปวางในโฟลเดอร์เดียวกับที่โหลดไฟล์จากระบบมาครับ")
        return

    print(f"📂 พบไฟล์ต้นฉบับที่ต้องแปลงทั้งหมด: {len(doc_files)} ไฟล์\n")

    # Create output directory
    output_dir = os.path.join(search_dir, 'converted docx files')
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 2. Setup Sandbox-safe paths in /tmp
    temp_dir = "/tmp/WordConversion"
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)
        
    success_count = 0

    print("🔄 กำลังเรียก Microsoft Word เข้าสู่กระบวนการแปลง...")

    for doc_file in doc_files:
        output_filename = os.path.basename(doc_file).replace('.doc', '.docx')
        output_path = os.path.join(output_dir, output_filename)

        print(f"⏳ กำลังแปลงไฟล์: {os.path.basename(doc_file)}")
        
        temp_input_filename = f"temp_{int(time.time())}_{os.path.basename(doc_file)}"
        temp_input_path = os.path.join(temp_dir, temp_input_filename)
        
        temp_output_filename = temp_input_filename.replace('.doc', '.docx')
        temp_output_path = os.path.join(temp_dir, temp_output_filename)
        
        shutil.copy2(doc_file, temp_input_path)
        
        # 3. AppleScript (osascript) logic
        apple_script = f'''
        tell application "Microsoft Word"
            activate
            set display alerts to none
            
            set inputFile to POSIX file "{temp_input_path}"
            set outputFile to "{temp_output_path}"
            
            with timeout of 600 seconds
                open inputFile
                set activeDoc to active document
                save as activeDoc file name outputFile file format format document
                close activeDoc saving no
            end timeout
        end tell
        '''
        
        try:
            process = subprocess.run(['osascript', '-e', apple_script], capture_output=True, text=True)
            
            if process.returncode == 0 and os.path.exists(temp_output_path):
                # Move completed .docx back
                shutil.move(temp_output_path, output_path)
                print(f"   ✅ สำเร็จ -> {output_filename}")
                success_count += 1
            else:
                print(f"   ❌ แปลงล้มเหลว (อาจติด Permission หรือไฟล์ผิดพลาด)")
                if process.stderr:
                    print(f"      Error: {process.stderr.strip()}")
                
        except Exception as e:
            print(f"   ❌ เกิดข้อผิดพลาด Python: {e}")
            
        finally:
            # Cleanup temp file for this iteration
            try: os.remove(temp_input_path) 
            except: pass

    # Clean up lock files after Word processing
    print("\n🧹 กำลังทำความสะอาดไฟล์ชั่วคราว (รอสูงสุด 1 นาที)...")
    timeout = 60
    start_time = time.time()
    
    while time.time() - start_time < timeout:
        # Match hidden lockfiles starting with ~$ or .~$ etc.
        lock_files = [f for f in glob.glob(os.path.join(search_dir, '.*')) + glob.glob(os.path.join(search_dir, '*')) 
                      if os.path.basename(f).startswith('~$') and (f.endswith('.doc') or f.endswith('.docx'))]
        
        if not lock_files:
            break
            
        all_deleted = True
        for lf in lock_files:
            try:
                os.remove(lf)
                print(f"   🗑️ ลบไฟล์ขยะ: {os.path.basename(lf)}")
            except:
                all_deleted = False
        
        if all_deleted:
            break
            
        time.sleep(1)
        
    remaining_lock_files = [f for f in glob.glob(os.path.join(search_dir, '.*')) + glob.glob(os.path.join(search_dir, '*')) 
                            if os.path.basename(f).startswith('~$') and (f.endswith('.doc') or f.endswith('.docx'))]
    if remaining_lock_files:
        for lf in remaining_lock_files:
            print(f"   ⚠️ ไม่สามารถลบได้ หมดเวลา 1 นาที (อาจค้างหรือมีคนเปิดอยู่): {os.path.basename(lf)}")

    print(f"\n🎉 สิ้นสุดกระบวนการ! แปลงไฟล์สำเร็จ: {success_count} / {len(doc_files)} ไฟล์")
    print(f"📁 ตรวจสอบไฟล์ผลลัพธ์ได้ที่โฟลเดอร์: converted docx files")

if __name__ == "__main__":
    convert_all_docs_to_docx()
